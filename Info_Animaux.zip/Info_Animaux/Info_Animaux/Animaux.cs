﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Info_Animaux
{
    class Animaux
    {
        public string Nom { get; set; }
        public string Famille { get; set; }
        public string Statut { get; set; }
        public string Genre { get; set; }

        public Animaux(string nom, string famille, string statut, string genre)
        {
            Nom = nom;
            Famille = famille;
            Statut = statut;
            Genre = genre;
        }
    }
}
