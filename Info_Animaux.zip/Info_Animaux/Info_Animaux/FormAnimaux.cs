﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Info_Animaux
{
    public partial class FormAnimaux : Form
    {
        Formulaire form;

        public FormAnimaux()
        {
            InitializeComponent();
            form = new Formulaire(this);

        }
        public void Affichage()
        {
            DbAnimaux.Affichage_recherche("SELECT ID, Nom, Famille, Statut, Genre FROM t_animaux", dataGridView);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_ajouter_Click(object sender, EventArgs e)
        {
            form.Vider();
            form.ShowDialog();
        }

        private void FormAnimaux_Shown(object sender, EventArgs e)
        {
            Affichage();
        }

        private void txt_recherche_TextChanged(object sender, EventArgs e)
        {
            DbAnimaux.Affichage_recherche("SELECT ID, Nom, Famille, Statut, Genre FROM t_animaux WHERE Nom LIKE'%"+ txt_recherche.Text + "%'", dataGridView);
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                form.Vider();
            form.id = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            form.nom= dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
            form.famille= dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
            form.@statut= dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
            form.genre= dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            form.ModifierInfo();
            form.ShowDialog();
            return;
            
              
            }
            if (e.ColumnIndex == 1)
            {
                if (MessageBox.Show("Voulez vous supprimer cet animal de la liste ?", "Information", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information)== DialogResult.Yes)
                {
                    DbAnimaux.SupprimerAnimaux(dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString());
                    Affichage();
                }
                return;
            }
        }
    }
}
