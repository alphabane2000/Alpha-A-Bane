﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Info_Animaux
{
    class DbAnimaux
    {
        public static MySqlConnection GetConnection()
        {
            string sql = "datasource=localhost;port=3306;username=root;password=;database=animaux";
            MySqlConnection con = new MySqlConnection(sql);
            try
            {
                con.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySql Connection \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return con;

        }

        public static void AjouterAnimaux(Animaux std)
        {
            string sql = "INSERT INTO t_animaux VALUES(NULL,@AnimauxNom, @AnimauxFamille, @AnimauxStatut, @AnimauxGenre , NULL)";
            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@AnimauxNom", MySqlDbType.VarChar).Value = std.Nom;
            cmd.Parameters.Add("@AnimauxFamille", MySqlDbType.VarChar).Value = std.Famille;
            cmd.Parameters.Add("@AnimauxStatut", MySqlDbType.VarChar).Value = std.Statut;
            cmd.Parameters.Add("@AnimauxGenre", MySqlDbType.VarChar).Value = std.Genre;
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Ajouter avec Succes.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Animal non inserer" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
        }

        public static void ModifierAnimaux(Animaux std, string id)
        {
            string sql = "UPDATE t_animaux SET Nom=@AnimauxNom, Famille=@AnimauxFamille, Statut=@AnimauxStatut, Genre=@AnimauxGenre WHERE ID=@AnimauxID";
            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@AnimauxID", MySqlDbType.VarChar).Value = id;
            cmd.Parameters.Add("@AnimauxNom", MySqlDbType.VarChar).Value = std.Nom;
            cmd.Parameters.Add("@AnimauxFamille", MySqlDbType.VarChar).Value = std.Famille;
            cmd.Parameters.Add("@AnimauxStatut", MySqlDbType.VarChar).Value = std.Statut;
            cmd.Parameters.Add("@AnimauxGenre", MySqlDbType.VarChar).Value = std.Genre;
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Mise a jour reussie.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Mise a jour echouee" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
        }
        public static void SupprimerAnimaux(string id)
        {
            string sql = "DELETE FROM t_animaux WHERE ID=@AnimauxID";
            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@AnimauxID", MySqlDbType.VarChar).Value = id;
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Suppresion reussie.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Suppresion echouee" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();

        }

        public static void Affichage_recherche(string query, DataGridView dgv)
        {
            string sql = query;
            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tbl = new DataTable();
            adp.Fill(tbl);
            dgv.DataSource=tbl;
            con.Close();

        }

    } 
}
