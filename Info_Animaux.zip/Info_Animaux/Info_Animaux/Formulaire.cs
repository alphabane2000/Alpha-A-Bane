﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Info_Animaux
{
    public partial class Formulaire : Form
    {
        private readonly FormAnimaux _parent;
        public string id, nom, famille, @statut, genre;
        public Formulaire(FormAnimaux parent)
        {
            InitializeComponent();
            _parent = parent;
        }
        public void ModifierInfo()
        {
            lbltext.Text = "Modification";
            btn_enregistrer.Text = "Modifier";
            txt_nom.Text = nom;
            txt_famille.Text = famille;
            txt_statut.Text = @statut;
            txt_genre.Text = genre;
        }

        public  void Vider()
        {
            txt_nom.Text = txt_famille.Text = txt_statut.Text = txt_genre.Text = string.Empty;
        }

        private void btn_enregistrer_Click(object sender, EventArgs e)
        {
            if (txt_nom.Text.Trim().Length < 3)
            {
                MessageBox.Show("le nom de l'animal est vide(>3)");
                return;
            }
            if (txt_famille.Text.Trim().Length < 1)
            {
                MessageBox.Show("la Famille de l'animal est vide(>1)");
                return;
            }
            if (txt_statut.Text.Trim().Length == 0)
            {
                MessageBox.Show("le Statut de l'animal est vide(>1)");
                return;
            }
            if (txt_genre.Text.Trim().Length == 0)
            {
                MessageBox.Show("le nom de l'animal est vide(>3)");
                return;
            }
            if(btn_enregistrer.Text == "Enregistrer")
            {
                Animaux std = new Animaux(txt_nom.Text.Trim(), txt_famille.Text.Trim(), txt_statut.Text.Trim(), txt_genre.Text.Trim());
                DbAnimaux.AjouterAnimaux(std);
                Vider();
            }
            if(btn_enregistrer.Text=="Modifier")
            {
                Animaux std = new Animaux(txt_nom.Text.Trim(), txt_famille.Text.Trim(), txt_statut.Text.Trim(), txt_genre.Text.Trim());
                DbAnimaux.ModifierAnimaux(std, id);
            }
            _parent.Affichage();
        }
    }
}
